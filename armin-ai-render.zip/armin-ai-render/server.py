import json
import urllib.request
import urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

PORT = int(__import__("os").environ.get("PORT", "8765"))
API_KEY = __import__("os").environ.get("OPENAI_API_KEY", "")
MODEL = "gpt-5.6-luna"

HTML = """
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Armin AI</title>

<style>
*{box-sizing:border-box}

body{
margin:0;
background:#101218;
color:white;
font-family:Tahoma,Arial,sans-serif;
height:100vh;
}

header{
height:65px;
background:#181b24;
border-bottom:1px solid #303441;
display:flex;
align-items:center;
justify-content:space-between;
padding:0 18px;
}

.logo{
font-size:22px;
font-weight:bold;
}

#clock{
color:#aeb4c5;
}

main{
height:calc(100vh - 65px);
display:flex;
flex-direction:column;
}

#chat{
flex:1;
overflow-y:auto;
padding:20px 10%;
}

.welcome{
text-align:center;
margin-top:12vh;
}

.robot{
font-size:65px;
}

.welcome h1{
font-size:30px;
}

.welcome p{
color:#aeb4c5;
}

.message{
display:flex;
margin:14px 0;
}

.user{
justify-content:flex-start;
}

.ai{
justify-content:flex-end;
}

.bubble{
max-width:80%;
padding:13px 17px;
border-radius:17px;
line-height:1.8;
white-space:pre-wrap;
word-break:break-word;
}

.user .bubble{
background:#303545;
}

.ai .bubble{
background:#1b1e27;
border:1px solid #303441;
}

#inputArea{
padding:12px 10%;
background:#12141b;
border-top:1px solid #303441;
}

.box{
background:#1b1e27;
border:1px solid #343846;
border-radius:18px;
padding:10px;
}

textarea{
width:100%;
height:50px;
resize:none;
background:transparent;
border:0;
outline:0;
color:white;
font-family:inherit;
font-size:16px;
direction:rtl;
}

.buttons{
display:flex;
gap:8px;
}

button{
border:0;
border-radius:11px;
padding:11px 15px;
background:#303545;
color:white;
font-size:15px;
cursor:pointer;
}

button:hover{
background:#41475a;
}

.send{
margin-right:auto;
background:#5b5cff;
}

.file{
display:none;
}

.preview{
display:none;
margin-bottom:8px;
}

.preview img{
max-width:130px;
max-height:130px;
border-radius:12px;
}

.modal{
display:none;
position:fixed;
inset:0;
background:#000b;
align-items:center;
justify-content:center;
}

.modalBox{
background:#1b1e27;
padding:22px;
border-radius:18px;
width:90%;
max-width:430px;
}

.modalBox input{
width:100%;
padding:13px;
border-radius:10px;
border:1px solid #3b4050;
background:#101218;
color:white;
direction:ltr;
}

@media(max-width:700px){
#chat,#inputArea{
padding-left:10px;
padding-right:10px;
}

.bubble{
max-width:90%;
}
}
</style>
</head>

<body>

<header>
<div class="logo">🤖 Armin AI</div>
<div id="clock">00:00:00</div>
</header>

<main>

<div id="chat">

<div class="welcome" id="welcome">
<div class="robot">🤖</div>
<h1>سلام آرمین 👋</h1>
<p>به Armin AI خوش آمدی!</p>
<button onclick="example()">💡 یک سؤال نمونه</button>
<button onclick="settings()">⚙️ API Key</button>
</div>

</div>

<div id="inputArea">

<div class="box">

<div class="preview" id="preview">
<img id="previewImg">
</div>

<textarea id="message"
placeholder="پیامت را بنویس..."
onkeydown="keyDown(event)"></textarea>

<div class="buttons">

<label>
<button onclick="document.getElementById('photo').click()">📷 عکس</button>
<input class="file" id="photo" type="file" accept="image/*" onchange="photoSelected(event)">
</label>

<button onclick="voice()">🎤</button>

<button class="send" onclick="send()">ارسال ➤</button>

</div>

</div>

</div>

</main>

<div class="modal" id="modal">

<div class="modalBox">

<h2>⚙️ API Key</h2>

<p>کلید API را وارد کن:</p>

<input id="key" type="password" placeholder="sk-...">

<br><br>

<button onclick="saveKey()">ذخیره</button>
<button onclick="closeSettings()">بستن</button>

<p id="status"></p>

</div>

</div>

<script>

let imageData = null;

function clock(){
let d=new Date();
let h=String(d.getHours()).padStart(2,"0");
let m=String(d.getMinutes()).padStart(2,"0");
let s=String(d.getSeconds()).padStart(2,"0");
document.getElementById("clock").textContent=h+":"+m+":"+s;
}

setInterval(clock,1000);
clock();

function example(){
document.getElementById("message").value=
"یک برنامه ساده پایتون برای من بنویس";
}

function settings(){
document.getElementById("modal").style.display="flex";
}

function closeSettings(){
document.getElementById("modal").style.display="none";
}

async function saveKey(){

let key=document.getElementById("key").value.trim();

if(!key){
document.getElementById("status").textContent="❌ کلید خالی است";
return;
}

try{

let r=await fetch("/api/key",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({key:key})
});

let d=await r.json();

if(d.ok){
document.getElementById("status").textContent=
"✅ API Key ذخیره شد";
document.getElementById("key").value="";
}else{
document.getElementById("status").textContent=
"❌ "+d.error;
}

}catch(e){
document.getElementById("status").textContent=
"❌ اتصال به Python برقرار نشد";
}

}

function photoSelected(e){

let file=e.target.files[0];

if(!file)return;

let reader=new FileReader();

reader.onload=function(){
imageData=reader.result;
document.getElementById("previewImg").src=imageData;
document.getElementById("preview").style.display="block";
};

reader.readAsDataURL(file);
}

function keyDown(e){

if(e.key==="Enter"&&!e.shiftKey){
e.preventDefault();
send();
}

}

function addMessage(text,type,image){

let chat=document.getElementById("chat");

let welcome=document.getElementById("welcome");

if(welcome)welcome.remove();

let row=document.createElement("div");
row.className="message "+type;

let bubble=document.createElement("div");
bubble.className="bubble";

if(text){
let t=document.createElement("div");
t.textContent=text;
bubble.appendChild(t);
}

if(image){
let img=document.createElement("img");
img.src=image;
img.style.maxWidth="220px";
img.style.maxHeight="220px";
img.style.display="block";
img.style.marginTop="8px";
img.style.borderRadius="12px";
bubble.appendChild(img);
}

row.appendChild(bubble);
chat.appendChild(row);

chat.scrollTop=chat.scrollHeight;
}

async function send(){

let input=document.getElementById("message");

let text=input.value.trim();

if(!text&&!imageData)return;

let img=imageData;

addMessage(text,"user",img);

input.value="";
imageData=null;
document.getElementById("preview").style.display="none";

addMessage("⏳ در حال فکر کردن...","ai");

let chat=document.getElementById("chat");

let loading=chat.lastElementChild;

try{

let r=await fetch("/api/chat",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({
message:text,
image:img
})
});

let d=await r.json();

loading.remove();

if(!r.ok||d.error){
addMessage("❌ "+(d.error||"خطا"),"ai");
return;
}

addMessage(d.answer,"ai");

}catch(e){

loading.remove();

addMessage(
"❌ اتصال برقرار نشد. مطمئن شو Python در حال اجراست.",
"ai"
);

}

}

function voice(){

let R=window.SpeechRecognition||
window.webkitSpeechRecognition;

if(!R){
alert("تشخیص صدا در این مرورگر پشتیبانی نمی‌شود.");
return;
}

let r=new R();

r.lang="fa-IR";

r.onresult=function(e){
document.getElementById("message").value+=
e.results[0][0].transcript;
};

r.start();

}

</script>

</body>
</html>
"""


def send_json(handler, data, status=200):
    raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def read_json(handler):
    try:
        length = int(handler.headers.get("Content-Length", "0"))
    except:
        length = 0

    raw = handler.rfile.read(length)

    if not raw:
        return {}

    try:
        return json.loads(raw.decode("utf-8"))
    except:
        return {}


def extract_answer(data):

    if data.get("output_text"):
        return str(data["output_text"])

    result = []

    for item in data.get("output", []):
        for part in item.get("content", []):
            if part.get("text"):
                result.append(str(part["text"]))

    return "\n".join(result).strip()


class Handler(BaseHTTPRequestHandler):

    def do_GET(self):

        if self.path == "/" or self.path == "/index.html":

            raw = HTML.encode("utf-8")

            self.send_response(200)
            self.send_header(
                "Content-Type",
                "text/html; charset=utf-8"
            )
            self.send_header(
                "Content-Length",
                str(len(raw))
            )
            self.end_headers()

            self.wfile.write(raw)

            return

        self.send_error(404)

    def do_POST(self):

        if self.path == "/api/key":
            self.api_key()
            return

        if self.path == "/api/chat":
            self.chat()
            return

        self.send_error(404)

    def api_key(self):

        global API_KEY

        data = read_json(self)

        key = str(data.get("key", "")).strip()

        if not key:
            send_json(
                self,
                {"ok":False,"error":"API Key خالی است."},
                400
            )
            return

        API_KEY = key

        send_json(self, {"ok":True})

    def chat(self):

        if not API_KEY:

            send_json(
                self,
                {
                    "error":
                    "اول از قسمت API Key کلیدت را وارد کن."
                },
                400
            )

            return

        data = read_json(self)

        message = str(
            data.get("message", "")
        ).strip()

        image = data.get("image")

        if not message and not image:

            send_json(
                self,
                {"error":"پیام خالی است."},
                400
            )

            return

        content = []

        if message:
            content.append({
                "type":"input_text",
                "text":message
            })

        if image:

            if not isinstance(image,str):
                send_json(
                    self,
                    {"error":"عکس نامعتبر است."},
                    400
                )
                return

            content.append({
                "type":"input_image",
                "image_url":image
            })

        # دستور اصلی Armin AI:
        # هویت، سبک پاسخ، ریاضیات، مباحث فنی و پزشکی آموزشی را تقویت می‌کند.
        developer_instruction = """
تو «هوش مصنوعی ارمین» هستی و وقتی از تو پرسیدند اسمت چیست، پاسخ بده:
«من هوش مصنوعی ارمین هستم.»

قوانین پاسخ:
1) پاسخ‌ها را دقیق، منطقی، روشن و تا حد امکان کاربردی بده.
2) در برنامه‌نویسی و مباحث فنی، مثل یک مهندس باتجربه عمل کن:
   کد کامل و قابل اجرا بده، خطاها را مرحله‌به‌مرحله بررسی کن و دلیل راه‌حل را توضیح بده.
3) در ریاضیات، مسئله را مرحله‌به‌مرحله حل کن، محاسبات را دوباره بررسی کن و جواب نهایی را واضح بنویس.
4) در علوم و پزشکی، نقش آموزشی داشته باش:
   مفاهیم آناتومی، فیزیولوژی، بیماری‌ها، داروها و آزمایش‌ها را دقیق و ساده توضیح بده.
   برای مسائل پزشکی، تشخیص قطعی یا تجویز شخصی انجام نده و در موارد جدی توصیه کن از پزشک یا خدمات درمانی کمک گرفته شود.
5) اگر سؤال فارسی است فارسی پاسخ بده؛ اگر انگلیسی است انگلیسی پاسخ بده.
6) اگر سؤال مبهم است، بهترین برداشت منطقی را بگو و در صورت نیاز یک سؤال کوتاه برای روشن شدن موضوع بپرس.
7) اطلاعات ساختگی یا منبع جعلی ارائه نکن.
"""

        # برای سؤال «اسمت چیه» پاسخ قطعی و بدون وابستگی به API هم در نظر گرفته می‌شود.
        identity_questions = {
            "اسمت چیه",
            "اسمت چیست",
            "اسم تو چیه",
            "نامت چیست",
            "who are you",
            "what is your name",
            "your name"
        }

        normalized = " ".join(message.lower().replace("؟", "").replace("?", "").split())

        if normalized in identity_questions:
            send_json(
                self,
                {"answer":"من هوش مصنوعی ارمین هستم."}
            )
            return

        payload = {
            "model":MODEL,
            "input":[
                {
                    "role":"developer",
                    "content":[
                        {
                            "type":"input_text",
                            "text":developer_instruction
                        }
                    ]
                },
                {
                    "role":"user",
                    "content":content
                }
            ]
        }

        body = json.dumps(payload).encode("utf-8")

        request = urllib.request.Request(
            "https://api.openai.com/v1/responses",
            data=body,
            headers={
                "Content-Type":"application/json",
                "Authorization":"Bearer "+API_KEY
            },
            method="POST"
        )

        try:

            with urllib.request.urlopen(
                request,
                timeout=120
            ) as response:

                raw=response.read()

            data=json.loads(
                raw.decode("utf-8")
            )

            answer=extract_answer(data)

            if not answer:
                answer="پاسخی دریافت نشد."

            send_json(
                self,
                {"answer":answer}
            )

        except urllib.error.HTTPError as e:

            try:
                raw=e.read().decode(
                    "utf-8",
                    errors="replace"
                )

                data=json.loads(raw)

                msg=data.get(
                    "error",
                    {}
                ).get(
                    "message",
                    "خطای API"
                )

            except:
                msg="خطای API"

            send_json(
                self,
                {"error":msg},
                e.code
            )

        except Exception as e:

            send_json(
                self,
                {"error":"خطا: "+str(e)},
                500
            )


print("================================")
print("          ARMIN AI")
print("================================")
print("")
print("SERVER STARTING...")
print("")

server = ThreadingHTTPServer(
    ("0.0.0.0", PORT),
    Handler
)

print("SERVER RUNNING")
print("Open: http://127.0.0.1:8765")
print("")

server.serve_forever()